var Mail={init:function(){}};jQuery(document).ready(function(){Mail.init()});
