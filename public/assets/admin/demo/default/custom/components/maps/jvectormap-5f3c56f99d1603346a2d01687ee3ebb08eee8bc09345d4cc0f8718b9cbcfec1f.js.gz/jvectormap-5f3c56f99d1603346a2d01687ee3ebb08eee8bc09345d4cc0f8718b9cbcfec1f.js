var jVectorMap={init:function(){}};jQuery(document).ready(function(){jVectorMap.init()});
