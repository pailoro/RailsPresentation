var SummernoteDemo={init:function(){$(".summernote").summernote({height:150})}};jQuery(document).ready(function(){SummernoteDemo.init()});
