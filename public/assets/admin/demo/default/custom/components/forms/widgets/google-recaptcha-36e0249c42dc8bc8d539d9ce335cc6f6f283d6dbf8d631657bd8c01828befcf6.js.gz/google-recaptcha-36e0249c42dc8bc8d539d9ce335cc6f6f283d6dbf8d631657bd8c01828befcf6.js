var BootstrapTouchspin={init:function(){}};jQuery(document).ready(function(){BootstrapTouchspin.init()});
