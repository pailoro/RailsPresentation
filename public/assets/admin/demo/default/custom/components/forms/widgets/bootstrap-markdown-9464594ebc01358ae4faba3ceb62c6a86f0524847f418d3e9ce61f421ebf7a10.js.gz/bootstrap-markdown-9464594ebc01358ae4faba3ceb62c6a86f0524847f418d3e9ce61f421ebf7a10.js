var BootstrapMarkdown={init:function(){}};jQuery(document).ready(function(){BootstrapMarkdown.init()});
