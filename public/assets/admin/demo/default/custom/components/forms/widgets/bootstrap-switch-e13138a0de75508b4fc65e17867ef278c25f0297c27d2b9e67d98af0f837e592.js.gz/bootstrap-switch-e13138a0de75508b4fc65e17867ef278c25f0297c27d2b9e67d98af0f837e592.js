var BootstrapSwitch={init:function(){$("[data-switch=true]").bootstrapSwitch()}};jQuery(document).ready(function(){BootstrapSwitch.init()});
