var Scrollable={init:function(){}};jQuery(document).ready(function(){Scrollable.init()});
